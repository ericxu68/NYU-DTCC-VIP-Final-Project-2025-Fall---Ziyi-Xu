package com.demo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class StaticLogger {
    private static final Logger logger = LogManager.getLogger(StaticLogger.class);

    public static void main(String[] args) {
        logger.info("Hello from StaticLogger: info");
        logger.warn("Hello from StaticLogger: warn");
        logger.error("Hello from StaticLogger: error");
        System.out.println("Static logger executed successfully.");
    }
}
