package com.demo;

import java.net.URL;
import java.net.URLClassLoader;
import java.lang.reflect.Method;

public class DynamicLogger {
    public static void main(String[] args) {
        try {
            // Force OS-level file access so strace can see openat() calls
            new java.io.FileInputStream("./lib/log4j-api-2.14.1.jar").close();
            new java.io.FileInputStream("./lib/log4j-core-2.14.1.jar").close();

            URL api = new URL("file:./lib/log4j-api-2.14.1.jar");
            URL core = new URL("file:./lib/log4j-core-2.14.1.jar");
            System.out.println("Loading JARs from: " + new java.io.File("./lib").getAbsolutePath());
            URLClassLoader loader = new URLClassLoader(new URL[]{ api, core }, null);
            System.out.println("Loaded URLs:");
            for (URL u : loader.getURLs()) {
                System.out.println("  " + u);
            }

            Thread.currentThread().setContextClassLoader(loader);

            Class<?> logManager = Class.forName("org.apache.logging.log4j.LogManager", true, loader);
            Class<?> loggerClass = Class.forName("org.apache.logging.log4j.Logger", true, loader);

            Method getLogger = logManager.getMethod("getLogger", Class.class);
            Object logger = getLogger.invoke(null, DynamicLogger.class);

            Method info = loggerClass.getMethod("info", Object.class);
            Method warn = loggerClass.getMethod("warn", Object.class);
            Method error = loggerClass.getMethod("error", Object.class);

            info.invoke(logger, "Hello from DynamicLogger: info");
            warn.invoke(logger, "Hello from DynamicLogger: warn");
            error.invoke(logger, "Hello from DynamicLogger: error");

            System.out.println("Dynamic logger executed successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
