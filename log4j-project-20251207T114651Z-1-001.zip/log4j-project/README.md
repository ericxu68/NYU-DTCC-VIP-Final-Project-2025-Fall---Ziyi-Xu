# Week 1: Static vs Dynamic Log4j

## 📁 Projects
- `static-log4j/` → uses Log4j at **compile-time** (declared in pom.xml)
- `dynamic-log4j/` → loads Log4j at **runtime** (from ./lib)

---

## 🧱 Static Version
Build and run:
```bash
cd static-log4j
mvn clean package
mvn -q -Dexec.mainClass=com.demo.StaticLogger exec:java
```

---

## ⚙️ Dynamic Version
Before running, download Log4j JARs and place them in `dynamic-log4j/lib/`:
- https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-api/2.14.1/log4j-api-2.14.1.jar
- https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-core/2.14.1/log4j-core-2.14.1.jar

Build and run:
```bash
cd dynamic-log4j
mvn clean package
java -cp target/classes com.demo.DynamicLogger
```
